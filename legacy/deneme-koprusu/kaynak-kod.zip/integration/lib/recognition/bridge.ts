import {subjects,counts,type Student,type Exam,type Question} from '../model';
import {randomId} from '../id';
import {enrichQuestion,matchOutcome} from '../curriculum';
import {matchActiveStudent} from './student-match';
import type {Recognition,RecordResult} from './types';
const names:Record<string,string>={TUR:subjects[0],MAT:subjects[1],FEN:subjects[2],INK:subjects[3],DIN:subjects[4],ING:subjects[5]};
export function bridgeRecognition(pack:any,students:Student[],name:string,date:string,hash:string):Recognition{
 if(pack?.schemaVersion!=='1.0.0'||!Array.isArray(pack.records)||!pack.records.length)throw Error('Geçerli Deneme Köprüsü sonuç verisi bulunamadı.');
 const records:RecordResult[]=pack.records.map((r:any)=>{
  if(!r.student?.name||!r.exam||!Array.isArray(r.subjects)||!Array.isArray(r.questions)||!r.recordId)throw Error('Deneme Köprüsü PDF verisi eksik.');
  const id=randomId(),source={page:r.source?.pages?.[0]||1,row:0,text:r.recordId},studentId=matchActiveStudent(r.student.name,students);
  const ss=r.subjects.map((s:any)=>({subject:names[s.id]||'',count:s.questionCount,d:s.correct,y:s.wrong,b:s.blank,net:s.net,source}));
  const questions:Question[]=r.questions.flatMap((q:any)=>{if(!names[q.subject]||!Number.isInteger(q.number)||q.number<1||q.number>counts[subjects.indexOf(names[q.subject])]||!/^[ABCD]$/.test(q.correctAnswer||''))return [];const answer=q.status==='blank'?'':q.studentAnswer;if(typeof answer!=='string'||!/^([ABCD])?$/.test(answer))return [];const status=!answer?'B':answer===q.correctAnswer?'D':'Y';if(({correct:'D',wrong:'Y',blank:'B'} as any)[q.status]!==status)return [];return [enrichQuestion({subject:names[q.subject],no:q.number,correct:q.correctAnswer,answer,status,code:q.questionOutcomeMethod==='SOURCE_ROW'?q.sourceOutcomeCode||'':'',topic:q.questionOutcomeMethod==='SOURCE_ROW'?q.sourceOutcomeText||'':''})]});
  const groups=(r.outcomeGroups||[]).flatMap((g:any)=>{const subject=names[g.subject];if(!subject||![g.questionCount,g.correct,g.wrong,g.blank].every(n=>Number.isInteger(n)&&n>=0)||g.correct+g.wrong+g.blank!==g.questionCount)return [];const m=matchOutcome(subject,g.sourceOutcomeCode||'',g.sourceOutcomeText||'');return [{subject,rawText:g.sourceOutcomeText||'',count:g.questionCount,d:g.correct,y:g.wrong,b:g.blank,sourcePage:source.page,verified:m.verified,code:m.verified?m.outcome?.code:undefined,officialText:m.verified?m.outcome?.officialText:undefined,matchMethod:m.method}]});
  const totals=subjects.map(subject=>{const s=ss.find((s:any)=>s.subject===subject);return {d:s?.d??0,y:s?.y??0,b:s?.b??0}});
  const exam:Exam={id,studentId,name,date,score:r.exam.score??null,totals,questions,created:new Date().toISOString()};
  return {id,studentId,identityConfirmed:!!studentId,studentName:r.student.name,className:r.student.class||'',schoolNumber:r.student.number||'',subjects:ss,score:r.exam.score??null,percentile:null,rank:null,reportedTotal:{net:r.exam.totalNet},source,warnings:[],selected:true,achievementGroups:groups,candidate:{exam,studentId,detectedName:r.student.name,warnings:[],selected:true,pageStart:source.page,text:r.recordId}};
 });
 return {publisher:'Deneme Köprüsü',name,date,examType:'lgs',documentType:'Öğrenci Sonuç Belgesi',adapter:'generic',fingerprint:'DENEME_BRIDGE_V1',formatChanged:false,pages:[],tables:[],records,hash,ocr:false,warnings:[],documentConfirmed:true};
}
export async function readBridgePDF(file:File,students:Student[],name:string,date:string,progress:(s:string)=>void){
 progress('Deneme Köprüsü PDF verisi doğrulanıyor…');
 const bytes=new Uint8Array(await file.arrayBuffer());if(bytes.length>30*1024*1024)throw Error('PDF en fazla 30 MB olabilir.');
 const {PDFDocument,PDFName,PDFDict,PDFArray,PDFRawStream,decodePDFRawStream}=await import('pdf-lib');
 const doc=await PDFDocument.load(bytes),names=doc.catalog.lookupMaybe(PDFName.of('Names'),PDFDict),tree=names?.lookupMaybe(PDFName.of('EmbeddedFiles'),PDFDict);
 let content:Uint8Array|undefined;
 function visit(node:import('pdf-lib').PDFDict){const list=node.lookupMaybe(PDFName.of('Names'),PDFArray);if(list)for(let i=0;i<list.size();i+=2){const key:any=list.lookup(i);if(key?.decodeText?.()!=='deneme-koprusu.json')continue;const spec=list.lookup(i+1,PDFDict),ef=spec.lookup(PDFName.of('EF'),PDFDict),stream=ef.lookup(PDFName.of('F'));if(!(stream instanceof PDFRawStream))throw Error('Köprü PDF verisi okunamadı.');content=decodePDFRawStream(stream).decode();}const kids=node.lookupMaybe(PDFName.of('Kids'),PDFArray);if(kids)for(let i=0;i<kids.size();i++)visit(kids.lookup(i,PDFDict));}
 if(tree)visit(tree);if(!content)throw Error('Bu PDF Deneme Köprüsü sonuç verisini içermiyor. Önce Köprü bölümünde dönüştürün ve PDF indirin.');
 const hash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(b=>b.toString(16).padStart(2,'0')).join('');return bridgeRecognition(JSON.parse(new TextDecoder().decode(content)),students,name,date,hash);
}
