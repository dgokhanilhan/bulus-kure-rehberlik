export async function convertBridge(file:File,progress:(s:string)=>void=()=>{}){
 const worker=new Worker('/bridge/engine/worker.mjs',{type:'module'});
 try{return await new Promise<any>(async(resolve,reject)=>{worker.onmessage=({data})=>{if(data.progress){progress(`Dönüştürülüyor · ${data.progress.page}/${data.progress.total}`);return;}data.error?reject(Error(data.error)):resolve(data.result)};worker.onerror=()=>reject(Error('Deneme Köprüsü motoru açılamadı. Sayfayı yenileyip tekrar deneyin.'));try{worker.postMessage(file.name.toLowerCase().endsWith('.json')?{id:1,kind:'json',text:await file.text()}:{id:1,kind:'pdf',name:file.name,bytes:new Uint8Array(await file.arrayBuffer())})}catch(e){reject(e)}})}finally{worker.terminate()}
}
