from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
root=Path(__file__).resolve().parents[1]
with ZipFile(root/'public/source.zip','w',ZIP_DEFLATED) as z:
 for f in root.rglob('*'):
  if not f.is_file():continue
  rel=f.relative_to(root)
  if any(x in rel.parts for x in ['node_modules','.git','.sites-runtime','.wrangler','.next','.vinext','dist','.openai','.agents','.codex']):continue
  if f.name in ['source.zip','test-parser.mjs','tsconfig.tsbuildinfo'] or f.name.startswith('.env'):continue
  z.write(f,rel.as_posix())
