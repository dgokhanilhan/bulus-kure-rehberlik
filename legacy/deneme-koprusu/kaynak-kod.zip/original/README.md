# Deneme Köprüsü

8. sınıf deneme sonuçlarını tarayıcıda ayrıştıran, PDF/PNG ve JSON olarak indiren uygulama.

## Çalıştırma ve taşıma
Node 22.13+ gerekir. `pnpm install --frozen-lockfile`, ardından `pnpm dev`.
Normal Sites kurulumu için paket yöneticisi ve mevcut kilit dosyası korunmalıdır.
`pnpm build` Cloudflare Worker çıktısını üretir. Yayımlarken yeni sitenin kendi kimliğini kullanın; bu kaynak paketi önceki site kimliğini içermez.

PDF motoru `public/engine/worker.mjs` içinden çalışır. Dosyalar sunucuya gönderilmez; kalıcı kayıt yapılmaz. Sayfa yenilenmeden önce sonuçları indirin.

## Dönüşüm
- `public/engine/parser.mjs`: üç düzen adaptörü (schoolnet_grouped_v1, hiz_cards_v1, fenomen_rows_v1), gömülü JSON içe alma, yazı tipi düzeltmesi, aritmetik kontroller.
- `lib/reports.ts`: aynı A4 şablonundan PDF; PDF içine JSON eki.
- MuPDF aynı PDF'yi PNG sayfalarına dönüştürür. Çok sayfalı görseller ZIP ile indirilir.
- `public/engine/schema.json`: DK 1.0.0 aktarım şeması.
- `public/engine/catalog.json`: resmi kaynak URL/sayfa bilgileriyle 326 kazanım (2018/Türkçe2019). Yeni yıla otomatik uygulanmaz.
- Öğrenci kaynak PDF'leri veya gerçek kayıtlar bu uygulama kaynak paketinde bulunmaz.

## Doğruluk sınırları
Puan ve kaynak neti korunur. Net D-Y/3 ile kontrol edilir; ders toleransı .011, toplam .051. Eksik null değerleri sıfıra dönüşmez. Özel anahtar sembolleri korunur. credited normal doğru cevaptan ayrıdır.
Soru-kazanım bağlantısı yalnız kaynak satırında varsa SOURCE_ROW olur. Grup toplamları sorulara keyfi dağıtılmaz; bu uygulama toplu kısıt çıkarımı yapmaz. Kaynak kodu ile resmi kod ayrı tutulur. Uyuşmayan resmi kod eşleşmeleri UNVERIFIED olur.
Tanınmayan PDF düzeni, tarama/OCR ihtiyacı, parola veya bozuk veri görünür hataya dönüşür. Her yayınevinin gelecekteki bütün düzenleri destekleniyor iddiası yoktur. Bildirilmemiş sayfalar sessizce atılmaz; tanınan liste/geçmiş sayfaları hariç işlenemeyen sayfalar görünür.

## Doğrulama
Gönderilen 10 dosyadaki 230 kayıt üzerinde altı ders özetleri, öğrenci bilgileri, puan/net, 20.590 sorunun cevap ve kaynak kazanım alanları önceki ayrıştırıcıyla karşılaştırıldı. Boş cevapta boşluk yerine null normalleştirmesi uygulanır. Kaynaktaki çelişkiler uyarı olarak kalır.

## WebMCP
`import_exam_results` aynı içe alma/doğrulama akışını ve görünür sonuç listesini kullanır. Tarayıcı bu API'yi desteklemiyorsa dosya yükleme normal çalışır.

## Lisanslar
Uygulama kaynakları GNU AGPL-3.0-or-later altında sunulur; LICENSE dosyasına bakın. MuPDF (AGPL) derlenmiş dosyaları `public/engine/mupdf` altında, upstream kaynakları https://github.com/ArtifexSoftware/mupdf.js adresindedir (npm mupdf 1.28.1). Lisans metni aynı dizinde bulunur. DejaVu yazı tipi lisansı public/fonts/FONT_LICENSE.txt içindedir. Diğer bağımlılıklar kendi lisansları altında dağıtılır; package.json / pnpm-lock.yaml sürümleri sabitler.

Tarayıcı QA notu: WebMCP modelContext test tarayıcısında bulunmadığından araç çağrısı doğrulaması yapılamadı. Dosya yükleme bu API'den bağımsızdır.
